export default function NewsPage() {
  return (
    <>
      <h1>Página de notícias</h1>
      <h1>Página de notícias</h1>
      <h1>Página de notícias</h1>
      <h1>Página de notícias</h1>
      <h1>Página de notícias</h1>
    </>
  );
}

/* TODO: ler url / slug / ver pokemon 
filtrar json (ler array) pelo objeto

*/

export default function NewsPageList() {
  return <></>;
}

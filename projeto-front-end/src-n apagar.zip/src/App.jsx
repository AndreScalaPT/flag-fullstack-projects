import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainNav from "./components/MainNav"; // invocar a pasta
import Footer from "./components/Footer";

import Home from "./pages/HomePage";
import Historial from "./pages/HistoricalPage";
import NewsPage from "./pages/news/NewsPage";
import Producoes from "./pages/ProductionsPage";
import Iniciativas from "./pages/InitiativesPage";
import Atividades from "./pages/ActivitiesPage";
import Contactos from "./pages/ContactsPage";
import NewsPageList from "./pages/NewsPageList";

function App() {
  return (
    <BrowserRouter basename="/projeto-front-end">
      <MainNav />

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/history" element={<History />} />
          <Route path="/news" element={<News />} />
          <Route path="/news/:slug" element={<NewsPage />} />
          <Route path="/productions" element={<Productions />} />
          <Route path="/initiatives" element={<Initiatives />} />
          <Route path="/activities" element={<Activities />} />
          <Route path="/contacts" element={<Contacts />} />
        </Routes>
      </main>

      <Footer />
    </BrowserRouter>
  );
}

export default App;

export default function NewsPage() {
  return (
    <>
      <h1>Página de notícias</h1>
    </>
  );
}

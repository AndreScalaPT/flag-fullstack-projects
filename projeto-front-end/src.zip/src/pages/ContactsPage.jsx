export default function ContactsPage() {
  return (
    <>
      <h1>Página de contactos</h1>
    </>
  );
}

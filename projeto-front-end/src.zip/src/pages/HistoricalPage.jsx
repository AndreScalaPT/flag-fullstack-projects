export default function Historial() {
  return (
    <>
      <h1>Página de historial</h1>
    </>
  );
}

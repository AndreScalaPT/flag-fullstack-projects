export default function InitiativesPage() {
  return (
    <>
      <h1>Página de iniciativas</h1>
    </>
  );
}

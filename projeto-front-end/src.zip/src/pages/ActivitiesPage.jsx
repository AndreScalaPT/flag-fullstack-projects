export default function ActivitiesPage() {
  return (
    <>
      <h1>Página de atividades</h1>
    </>
  );
}

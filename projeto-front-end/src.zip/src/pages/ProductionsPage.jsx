export default function ProductionsPage() {
  return (
    <>
      <h1>Página de produções</h1>
    </>
  );
}

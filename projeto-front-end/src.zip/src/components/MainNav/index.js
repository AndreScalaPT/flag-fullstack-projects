/* Posso importar todos os componentes da pasta MainNav invocando apenas o nome da pasta */
import MainNav from "./MainNav";
export default MainNav;
